#!/bin/bash

echo "Hey!! Welcome Buddy !!"