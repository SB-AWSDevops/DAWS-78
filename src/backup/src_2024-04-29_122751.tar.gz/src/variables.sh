#!/bin/bash


echo "enter the username: "
read -s username
echo "enter the password: "
read -s password
echo "username is  $username and password is  $password"