#!/bin/bash

course="AWS"